<?php require_once dirname(__FILE__) . '/header.php'; ?>

    <main class="main_content_area">
      Hello

      <!-- Section  -->
      <section class="wrapper"></section>
      <!-- Section  -->
      <section class="wrapper"></section>
      <!-- Section  -->
      <section class="wrapper"></section>
      <!-- Section  -->
      <section class="wrapper"></section>
      <!-- Section  -->
      <section class="wrapper"></section>
      <!-- Section  -->
      <section class="wrapper"></section>
    </main>

    <?php require_once dirname(__FILE__) . '/footer.php'; ?>
