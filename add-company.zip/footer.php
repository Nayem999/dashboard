
    <!-- JS Here -->
    <script src="./assets/plugins/js/jquery-3.6.0.min.js"></script>
    <script src="./assets/plugins/js/bootstrap.bundle.min.js"></script>
    <script src="./assets/plugins/js/swiper-bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.js"></script>
    <script src="./assets/plugins/js/jquery.rcounter.js"></script>
    <script src="./assets/plugins/js/jquery-modal-video.min.js"></script>
    <script src="./assets/plugins/js/jquery.nice-select.min.js"></script>
    <script src="./assets/plugins/js/jquery.magnific-popup.min.js"></script>
    <script src="./assets/plugins/js/jquery.rcounter.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.js"></script>
    <script src="./assets/plugins/js/jquery.rcounter.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.js"></script>
    <script src="./assets/plugins/js/select2.min.js"></script>
    <script src="./assets/plugins/js/summernote-lite.min.js"></script>
    <script src="./assets/plugins/js/rangeslider.min.js"></script>
    <script src="assets/js/main.js"></script>
    <script src="https://kit.fontawesome.com/46f35fbc02.js" ></script>
    <!-- Chart Resources -->
    <script src="https://cdn.amcharts.com/lib/5/index.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/xy.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/percent.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/radar.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>
    

  </body>
</html>